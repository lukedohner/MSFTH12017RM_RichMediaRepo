FT.manifest({
	"filename": "index.html",
	"width": 970,
	"height": 250,
	"clickTagCount": 1,
	"richLoads": [{
		"name": "sRichload",
		"src": "richload"
	}],
	"trackingEvents":[
	{"name":"replayClick", "type": "string"},
	{"name":"Next_Versatility", "type": "string"},
	{"name":"Next_Touchscreen", "type": "string"},
	{"name":"Next_Battery_Life", "type": "string"},
	{"name":"Learn_More", "type": "string"},
	{"name":"Next_Offer", "type": "string"}
	]
});